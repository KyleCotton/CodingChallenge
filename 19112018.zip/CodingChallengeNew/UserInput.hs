module UserInput where
import Game

setAliveStates :: [Location]
setAliveStates = undefined
