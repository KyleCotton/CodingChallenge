-- Haskell Programming Challenge
-- Created By: Kyle Cotton, Jasper Kettle, Dylan Lyons, Yannik Nelson
-- ~~~ Game of Life ~~~

{- NOTES:
To Compile: ghc Haq.hs
Toi Run   : ./Haq
-}

--import qualified GuiWindow
import qualified Rendering

import System.Environment
main :: IO ()
main = Rendering.main


 
